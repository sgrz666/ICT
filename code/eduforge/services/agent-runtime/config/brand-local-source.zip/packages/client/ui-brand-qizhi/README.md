---
description: "启智AGENT brand occupants for the Web client's sidebar and conversation hero slots, replacing the official DeepSeek marks."
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-brand-qizhi

A deployment brand package that fills the generic browser-brand slots with the
**启智AGENT** identity: the sidebar mark, the sidebar name, and the empty-session
hero emblem with its ambient particle layer. It is the alternative-brand package
that [`dsh-client-ui-brand-official`](../ui-brand-official/README.md) points to
when it says a differently-branded deployment should supply its own package.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)

-----

<a id="use-this-package"></a>
## Use this package

Mount it in place of the official brand row. The web-app bundle does exactly
that in `packages/bundle/web-app/cordis.patch.yml`:

```yaml
- id: ui-brand-qizhi
  name: '@deepseek-ai/dsh-client-ui-brand-qizhi'
```

Three slots change hands, and nothing else:

| Slot | Owner surface | Shipped fallback | This package |
|---|---|---|---|
| `sidebar.brand.mark` | `ui-sidebar` (`SidebarRoot.tsx`) | `FishLogo` | `QizhiBrandMark` — hexagonal core, four-point spark, three circuit nodes |
| `sidebar.brand.name` | `ui-sidebar` | `brand.localBuild` text | `QizhiBrandName` — 启智 in a gradient, `AGENT` in tracked capitals |
| `conversation.hero.brand.mark` | `ui-conversation` (`EmptyHero.tsx`) | animated hero fish | `QizhiHeroEmblem` — glowing core with a slow orbit ring, plus the particle layer |

The `official` build-profile gate is deliberately absent: this brand is not an
overlay applied to a signed build, it is the deployment's own brand, so it
occupies its slots whenever it is mounted.

<a id="understand-the-implementation"></a>
## Understand the implementation

`src/index.ts` keeps an empty host `apply` so the Loader has a host-side row;
all presentation ships through `exports["./client"]`. `src/client/index.ts`
declares `inject = ['slots', 'theme']`, publishes the glass token layer, and
registers the three occupants inside nested
`ctx.slots.inject` calls, mirroring the official package's shape: each
`register` returns a disposer, so unloading this plugin returns every slot to
its shell fallback.

`src/client/Brand.tsx` draws the mark as one `currentColor` SVG shape set, so
the host's own label color keeps it legible at 24 px in the collapsed rail and
at hero size. The wordmark is text, not an image: it localizes, stays
selectable, and inherits the interface font.

`src/client/ParticleField.tsx` is the only animated piece. One Canvas 2D context
portalled to `document.body`: nodes drift at 11 px/s, wrap at the viewport edge,
and stroke links inside 132 px. Budget scales with area
(`width*height / 26_000`, clamped to 24–90 nodes), device-pixel ratio is capped
at 2, the loop pauses on `document.hidden`, `prefers-reduced-motion` renders a
single static frame, and resize re-seeds proportionally instead of restarting.
The layer is `pointer-events: none` with `mix-blend-mode: screen`, so it adds
glow on dark chrome without covering headline or composer text and cannot
intercept a click.

`src/client/glass.ts` carries the theme half, and it goes through the channel
`ui-theme` reserves for third-party themes: `ctx.theme.overrideTokens(source,
tokens)` stacks a partial alias layer over whichever base palette is active, and
`ui-layout`'s presenter writes each value as an inline variable on `body`. That
is why no stylesheet here fights the vendor sheet for specificity — inline
tokens simply are the active palette. Every token ships a `{ light, dark }`
pair, because a single value would go illegible the moment the user switches
scheme. `src/styles/qizhi-theme.css` therefore keeps only what a token cannot
express: the fixed ambient radial mesh behind `#root`, the document canvas
colour, and the `backdrop-filter` that turns the now-translucent fills into
frosted panels.

The layer moves surface fills (`--dsw-alias-bg-base`,
`--dsw-specific-sidebar-fill`, `--dsw-specific-input-major`, the three
`bg-layer-*`, overlay, platform module, skeleton), the four `border-l*`
hairlines — which `--dsw-elevation-stroke-color` follows, so elevated surfaces
pick up the brand hairline without a hand-made shadow — and the brand/link and
interactive hover accents. It never touches text tokens.

Opacity is not uniform, and the reason is a real defect: only the two surfaces
that sit directly on the ambient backdrop — the app canvas (`bg-base`) and the
sidebar column — are see-through. Every token a panel, card or drawer paints
*over app content* stays near-opaque (α ≥ 0.94), because a translucent fill
there smears the transcript behind it. `tests/glass.spec.ts` pins that split so
a future sweep cannot re-open it. Three upstream rules
were treated as binding while choosing those: modal backdrops keep
`--dsw-mask-blur: none` (no blur through a settings dialog), menu material
(`--dsw-menu-surface-fill`, `--dsw-menu-backdrop-filter`) is not redefined and
stays the shipped 40 px glass, and no surface pairs a `border-l*` outline with
an elevation shadow.

`buildGlassTokens(glass)` takes one capability flag: when the engine cannot
composite a blur, or the OS asks for reduced transparency, the same keys are
published with opaque values so a panel never shows other people's text through
it.

<a id="model-experience"></a>
## Model Experience

#### What the model sees

Nothing. This package contributes browser presentation only: no prompt section,
no tool schema, no session event, and no request field. The system prompt,
tool list, and message history are byte-identical with it mounted or unmounted.

#### KV-cache and token effect

Zero. It changes no model-visible text, so it neither extends nor invalidates a
cached request prefix.

<a id="known-limitations-and-deferred-work"></a>
## Known Limitations and Deferred Work

- **Copy that lives outside the slots is still edited in place.** The hero
  headline and its subtitle are plain locale keys in `ui-conversation`
  (`hero.headline`, `hero.subheading`) and the document title comes from
  `brand.localBuild` in `packages/client/locale`; a brand package cannot reach
  them, so those strings were changed at their source. A future brand slot for
  the hero copy would let this package own them entirely.
- **`ui-brand-official` stays installed but unmounted.** Keeping the dependency
  row in `web-app/package.json` preserves the official build path; only the
  composition changed.
- **The frost needs a nameable surface, and CSS modules hide it.** Fill colours
  reach every component through tokens, but `backdrop-filter` has no token, so
  it is applied through selectors that survive hashing only by convention:
  `aside` and the readable local-name suffix `_sidebarCol` — one surface, the
  sidebar column, chosen because it is the only large element that paints its
  own translucent fill. The list is short on purpose: blurring a *transparent*
  layout wrapper (`nav`, `header`, `[class*='_panel']`, the composer seat)
  frosts whatever content sits under it, which is how an earlier, broader
  version of this rule ate half the page. An upstream rename drops the frost on
  that surface; the fill and the layout are unaffected.
- **Capability is read once, at activation.** `ctx.theme.overrideTokens` is a
  stored layer, so a mid-session OS switch of `prefers-reduced-transparency`
  does not re-pick opaque fills; a reload does. Engine blur support cannot
  change within a session.
- **Only one palette was observable live.** The running browser resolved
  `system` to light, so the light path is measured in the DOM; the dark values
  are pinned by `tests/glass.spec.ts` (every token carries both modes) rather
  than by a screenshot.
- **Chat-area chrome follows the palette, not a separate design.** Message
  bubbles and tool cards inherit the rebinded `bg-layer-*` and hairlines; the
  conversation typography is untouched.
- **The orbit ring and particles are decorative** and hidden from the
  accessibility tree, so assistive tech sees the same hero as before.
- **Bilingual README pairing** is maintained by hand here; the repository's
  `verify-translation-pairing` gate owns the canonical form.
