import type { HeroBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { SidebarBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client'
import css from './brand.module.css'
import { ParticleField } from './ParticleField.tsx'

/** Hero emblem presentation, taken from its declaring surface. */
type HeroEmblemProps = HeroBrandMarkOwnerProps

/**
 * 启智AGENT core glyph: a hexagonal agent core carrying a four-point spark and
 * three circuit nodes on its vertices. One `currentColor` shape set keeps it
 * legible at 24 px in the sidebar rail and at hero size.
 * @param props - host-supplied mark presentation.
 * @returns the brand mark element.
 */
export function QizhiBrandMark({ size }: SidebarBrandMarkOwnerProps) {
  return (
    <svg
      className={css.mark}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
    >
      <path
        className={css.core}
        d="M12 2.4 20.4 7.2v9.6L12 21.6 3.6 16.8V7.2z"
        stroke="currentColor"
        strokeWidth={1.4}
        strokeLinejoin="round"
      />
      <path
        d="M12 6.6 13.35 10.65 17.4 12 13.35 13.35 12 17.4 10.65 13.35 6.6 12 10.65 10.65z"
        fill="currentColor"
      />
      <circle cx="12" cy="2.4" r="1.3" fill="currentColor" />
      <circle cx="20.4" cy="16.8" r="1.3" fill="currentColor" />
      <circle cx="3.6" cy="16.8" r="1.3" fill="currentColor" />
    </svg>
  )
}

/**
 * The product name artwork: 启智 keeps the Chinese reading, `AGENT` is spaced
 * capitals for platform weight. Text, not an image, so it localizes and stays
 * selectable.
 * @returns the brand name element.
 */
export function QizhiBrandName() {
  return (
    <span className={css.name}>
      <span className={css.nameZh}>启智</span>
      <span className={css.nameEn}>AGENT</span>
    </span>
  )
}

/**
 * The empty-session emblem. It replaces the shipped animated-fish fallback by
 * occupying the same `conversation.hero.brand.mark` slot: a larger core with a
 * slow orbit ring, plus the ambient particle layer behind the hero stack. The
 * layer is `pointer-events: none` and unmounts with the hero, so it never
 * intercepts the composer or the workspace chip.
 * @param props - host-supplied hero presentation.
 * @returns the hero emblem element.
 */
export function QizhiHeroEmblem({ size, className }: HeroEmblemProps) {
  const edge = Math.max(size, 44)
  return (
    <>
      <span className={[css.hero, className ?? ''].filter(Boolean).join(' ')}>
        <svg
          className={css.heroGlyph}
          width={edge}
          height={edge}
          viewBox="0 0 24 24"
          fill="none"
          aria-hidden="true"
        >
          <circle
            className={css.orbit}
            cx="12"
            cy="12"
            r="11"
            stroke="currentColor"
            strokeWidth={0.6}
            strokeDasharray="2 4"
            strokeLinecap="round"
            opacity={0.55}
          />
          <path
            className={css.core}
            d="M12 2.4 20.4 7.2v9.6L12 21.6 3.6 16.8V7.2z"
            stroke="currentColor"
            strokeWidth={1.4}
            strokeLinejoin="round"
          />
          <path
            d="M12 6.6 13.35 10.65 17.4 12 13.35 13.35 12 17.4 10.65 13.35 6.6 12 10.65 10.65z"
            fill="currentColor"
          />
        </svg>
      </span>
      <ParticleField />
    </>
  )
}
