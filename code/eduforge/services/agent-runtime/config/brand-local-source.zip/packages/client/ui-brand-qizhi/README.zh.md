---
description: "为 Web 客户端侧栏与会话首屏品牌槽位填充 启智AGENT 标识的部署品牌包，取代官方 DeepSeek 品牌。"
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-brand-qizhi

一个部署品牌包，把通用的浏览器品牌槽位换成 **启智AGENT**：侧栏标志、侧栏名称，
以及空会话首屏徽标与它的氛围粒子层。官方
[`dsh-client-ui-brand-official`](../ui-brand-official/README.zh.md) 明确说「使用其他品牌的部署应提供替代品牌包」，
本包就是那个替代包。

## 目录

- [使用本包](#use-this-package)
- [实现说明](#understand-the-implementation)
- [模型视角](#model-experience)
- [已知限制与后续工作](#known-limitations-and-deferred-work)

-----

<a id="use-this-package"></a>
## 使用本包

用它替换官方品牌行。`packages/bundle/web-app/cordis.patch.yml` 就是这么做的：

```yaml
- id: ui-brand-qizhi
  name: '@deepseek-ai/dsh-client-ui-brand-qizhi'
```

只有三个槽位换了主人：

| 槽位 | 所属界面 | 出厂回退 | 本包 |
|---|---|---|---|
| `sidebar.brand.mark` | `ui-sidebar`（`SidebarRoot.tsx`） | `FishLogo` | `QizhiBrandMark` —— 六边形核心 + 四芒星 + 三个电路节点 |
| `sidebar.brand.name` | `ui-sidebar` | `brand.localBuild` 文本 | `QizhiBrandName` —— 「启智」渐变 + 大字距 `AGENT` |
| `conversation.hero.brand.mark` | `ui-conversation`（`EmptyHero.tsx`） | 动画鱼 | `QizhiHeroEmblem` —— 辉光核心 + 缓慢轨道环 + 粒子层 |

本包刻意**不加** `official` 构建 profile 门控：它不是叠加在签名构建上的皮肤，
而是这个部署自己的品牌，挂载即生效。

<a id="understand-the-implementation"></a>
## 实现说明

`src/index.ts` 的主机侧 `apply` 为空，只为让 Loader 有一行主机配置；全部表现走
`exports["./client"]`。`src/client/index.ts` 声明 `inject = ['slots', 'theme']`，先发布毛玻璃 token 层，再在与官方包
相同的嵌套 `ctx.slots.inject` 结构里注册三个占用者；每个 `register` 都返回释放器，
卸载本插件即把三个槽位交回外壳回退。

`src/client/Brand.tsx` 用单一 `currentColor` 的 SVG 形状组绘制标志，因此沿用宿主
自身标签色，折叠栏 24 px 与首屏尺寸都清晰。名称是文本而非图片：可本地化、可选中、
继承界面字体。

`src/client/ParticleField.tsx` 是唯一的动画件。一个 Canvas 2D，portal 到
`document.body`：节点以 11 px/s 漂移、出屏回绕、距离小于 132 px 时连线。数量随面积
取值（`width*height / 26_000`，夹在 24–90），设备像素比封顶 2，页面隐藏时停循环，
`prefers-reduced-motion` 只画一帧静态，resize 按比例重播种而非重启。该层
`pointer-events: none` 且 `mix-blend-mode: screen`，在深色底上只加辉光、不遮挡标题与
输入框，也无法截获点击。

主题这一半走 `ui-theme` 为第三方主题预留的通道：`src/client/glass.ts` 调用
`ctx.theme.overrideTokens(source, tokens)`，把一层局部 alias 覆盖叠在用户当前选中的基础调色板之上，
`ui-layout` 的呈现器再把每个值写成 `body` 上的行内变量——所以本包的样式表不必和厂商样式表比选择器权重，
行内 token 就是生效中的调色板。每个 token 都必须给 `{ light, dark }` 两个值，只给一个值会在用户切换深浅色时变得不可读。
`src/styles/qizhi-theme.css` 因此只保留 token 表达不了的东西：`#root` 之后那层固定的径向氛围底、文档画布底色，
以及把已经半透明的面板真正磨成毛玻璃的 `backdrop-filter`。

这层改动搬的是表面填充（`--dsw-alias-bg-base`、`--dsw-specific-sidebar-fill`、
`--dsw-specific-input-major`、三层 `bg-layer-*`、overlay、平台模块底、骨架屏）、四条 `border-l*` 细线
（`--dsw-elevation-stroke-color` 跟着它走，所以抬升面板自然换上品牌描边，不需要手搓阴影），以及品牌/链接与
hover 交互强调色；文字类 token 一个都没动。

透明度不是一刀切，原因是一次真实缺陷：只有直接坐在氛围底上的两个表面——应用画布
（`bg-base`）与侧栏列——是透的；所有「盖在应用内容之上」的面板、卡片、抽屉的填充都保持
接近不透明（α ≥ 0.94），因为半透明填在那里会把底下的会话流糊穿。`tests/glass.spec.ts`
把这条分界钉住，防止下一轮统一主题时再把它打开。挑选时把三条上游规矩当作硬约束：模态遮罩保持
`--dsw-mask-blur: none`（设置对话框后面不糊）、菜单材质（`--dsw-menu-surface-fill` 与
`--dsw-menu-backdrop-filter`）不重定义并沿用出厂的 40px 玻璃、任何表面都不把 `border-l*` 描边和抬升阴影叠在一起。

`buildGlassTokens(glass)` 只接一个能力开关：浏览器不支持合成模糊、或系统要求减少透明度时，同样的键改用不填充值发布，
面板不会把别人的文字透出来。

<a id="model-experience"></a>
## 模型视角

#### 模型看到什么

什么都看不到。本包只做浏览器端表现：不添加提示词分节、不添加工具 schema、不产生
会话事件、不改请求字段。挂载与不挂载时，系统提示词、工具列表与消息历史逐字节一致。

#### 对 KV cache 与 token 的影响

为零。不改变任何模型可见文本，因此既不会延长也不会使已缓存的请求前缀失效。

<a id="known-limitations-and-deferred-work"></a>
## 已知限制与后续工作

- **槽位之外的文案仍在源头就地修改。** 首屏主标题与副标题是 `ui-conversation` 的
  locale 键（`hero.headline`、`hero.subheading`），文档标题取自
  `packages/client/locale` 的 `brand.localBuild`；品牌包够不着它们，所以这些字符串
  是在原处改的。若上游将来为文案开一个首屏品牌槽位，本包就能完全接管。
- **`ui-brand-official` 仍被安装但不挂载。** 保留 `web-app/package.json` 里的依赖行
  是为了不破坏官方构建路径，改的只是组合。
- **磨砂要能点名表面，而 CSS module 把名字藏起来了。** 填充色靠 token 能到达所有组件，
  `backdrop-filter` 却没有对应 token，只能用「哈希后仍能存活」的选择器，最终只留两个：
  `aside` 与可读局部名后缀 `_sidebarCol`——也就是侧栏列，选它是因为它是唯一「自己画半透明填充」
  的大表面。列表刻意很短：给*透明*的布局容器加模糊（`nav`、`header`、`[class*='_panel']`、
  composerSeat）等于把它下面的内容一起磨掉，本层更早一版就是因为范围太宽糊掉了半张页面。
  上游改名只会让那一处的磨砂悄悄失效——填充与布局不受影响。
- **能力只在激活时读一次。** `ctx.theme.overrideTokens` 是常驻层，系统中途切换
  `prefers-reduced-transparency` 不会重新换成不填充值，刷新才会；引擎是否支持模糊在一次会话里不会变。
- **实机只观测到一套配色。** 运行中的浏览器把 `system` 解析成浅色，所以浅色路径是 DOM 实测的；
  深色取值由 `tests/glass.spec.ts` 钉住（每个 token 都必须带两套模式），不是截图证明的。
- **会话区跟的是调色板，不是另一套设计。** 气泡与工具卡继承被重绑的 `bg-layer-*` 与细线，
  会话排版字号未动。
- **轨道环与粒子都是装饰**，已对无障碍树隐藏，辅助技术看到的结构与之前一致。
- **双语 README 配对**此处手工维护，仓库的 `verify-translation-pairing` 门才是权威形式。
