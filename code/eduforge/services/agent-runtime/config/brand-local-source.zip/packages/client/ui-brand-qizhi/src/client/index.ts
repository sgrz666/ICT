/** 启智AGENT occupants for the generic browser-brand slots. */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-theme/client'
import { QizhiBrandMark, QizhiBrandName, QizhiHeroEmblem } from './Brand.tsx'
import { applyGlassTheme } from './glass.ts'

/** Required services: the UI slot registry and the theme registry. */
export const inject = ['slots', 'theme']

/**
 * Fill the two sidebar brand slots and the conversation hero mark slot, and
 * publish the deployment's glass token layer.
 *
 * Unlike the official package, registration is not gated on
 * `DSH_CLIENT_BUILD_PROFILE`: this brand ships as the deployment's own brand,
 * so it occupies every slot the shell asks a brand plugin for — including
 * `conversation.hero.brand.mark`, which the official build deliberately leaves
 * to its animated-fish fallback. Registrations are effects, so unloading this
 * plugin returns all three slots to their shell defaults and drops the token
 * layer with them.
 * @param ctx - Client root context.
 */
export function apply(ctx: ClientContext): void {
  applyGlassTheme(ctx)
  ctx.slots.inject('sidebar.brand.mark', () =>
    ctx.slots.inject('sidebar.brand.name', () =>
      ctx.slots.inject('conversation.hero.brand.mark', function* () {
        yield ctx.slots.register({ name: 'sidebar.brand.mark' }, QizhiBrandMark)
        yield ctx.slots.register({ name: 'sidebar.brand.name' }, QizhiBrandName)
        yield ctx.slots.register({ name: 'conversation.hero.brand.mark' }, QizhiHeroEmblem)
      })))
}
