/**
 * 启智AGENT glass layer: alias-token overrides registered through the theme
 * service, the repo's sanctioned third-party theme channel.
 *
 * The presenter writes these as inline variables on `body`, so they apply over
 * whichever base palette is active and no stylesheet has to out-specify the
 * vendor sheet. Each token carries both palette modes, and only surface fills,
 * hairlines and brand accents move — text tokens keep upstream contrast.
 *
 * See-through is limited to the two surfaces that sit directly on the ambient
 * backdrop: the app canvas (`bg-base`) and the sidebar column. Every token a
 * panel, card or drawer paints *over app content* stays near-opaque — a
 * translucent fill there smears the transcript behind it.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client'

/** Ownership name for this layer in the theme service's override stack. */
const SOURCE = 'dsh-client-ui-brand-qizhi'

/** Translucent surface fills need compositing to stay readable. */
function hasCompositing(): boolean {
  return CSS.supports('backdrop-filter', 'blur(1px)') || CSS.supports('-webkit-backdrop-filter', 'blur(1px)')
}

/** Users who ask the OS for flat surfaces get opaque fills. */
function prefersFlat(): boolean {
  return matchMedia('(prefers-reduced-transparency: reduce)').matches
}

/**
 * Build the token layer for the current capability.
 * @param glass - Whether translucent panels are safe on this browser.
 * @returns Override dictionary keyed by CSS custom property name.
 */
export function buildGlassTokens(glass: boolean): ThemeTokenOverrides {
  const base = glass
    ? { light: 'rgba(255, 255, 255, 0.60)', dark: 'rgba(11, 13, 22, 0.58)' }
    : { light: '#ffffff', dark: '#0f1115' }
  return {
    '--dsw-alias-bg-base': base,
    '--dsw-specific-sidebar-fill': glass
      ? { light: 'rgba(255, 255, 255, 0.68)', dark: 'rgba(16, 19, 28, 0.62)' }
      : { light: '#ffffff', dark: '#14171f' },
    '--dsw-specific-input-major': glass
      ? { light: 'rgba(255, 255, 255, 0.97)', dark: 'rgba(31, 36, 54, 0.96)' }
      : { light: '#ffffff', dark: '#232324' },
    '--dsw-alias-bg-layer-1': glass
      ? { light: 'rgba(255, 255, 255, 0.94)', dark: 'rgba(19, 22, 33, 0.94)' }
      : { light: '#ffffff', dark: '#14171f' },
    '--dsw-alias-bg-layer-2': glass
      ? { light: 'rgba(255, 255, 255, 0.96)', dark: 'rgba(24, 28, 42, 0.95)' }
      : { light: '#f7f8fc', dark: '#191d29' },
    '--dsw-alias-bg-layer-3': glass
      ? { light: 'rgba(255, 255, 255, 0.97)', dark: 'rgba(31, 36, 54, 0.96)' }
      : { light: '#eef1f8', dark: '#212637' },
    '--dsw-alias-bg-overlay': glass
      ? { light: 'rgba(255, 255, 255, 0.97)', dark: 'rgba(13, 16, 26, 0.96)' }
      : { light: '#ffffff', dark: '#10131d' },
    '--dsw-alias-bg-module-platform': glass
      ? { light: 'rgba(255, 255, 255, 0.95)', dark: 'rgba(24, 28, 42, 0.95)' }
      : { light: '#f4f6fb', dark: '#171a25' },
    '--dsw-alias-bg-skeleton': glass
      ? { light: 'rgba(12, 18, 34, 0.05)', dark: 'rgba(255, 255, 255, 0.06)' }
      : { light: '#0000000a', dark: '#ffffff0f' },
    '--dsw-alias-border-l1': { light: 'rgba(12, 18, 34, 0.04)', dark: 'rgba(255, 255, 255, 0.07)' },
    '--dsw-alias-border-l2': { light: 'rgba(12, 18, 34, 0.08)', dark: 'rgba(255, 255, 255, 0.10)' },
    '--dsw-alias-border-l3': { light: 'rgba(12, 18, 34, 0.12)', dark: 'rgba(255, 255, 255, 0.14)' },
    '--dsw-alias-border-l4': { light: 'rgba(124, 92, 255, 0.28)', dark: 'rgba(56, 225, 255, 0.26)' },
    '--dsw-alias-brand-primary': { light: '#0e9cc0', dark: '#38e1ff' },
    '--dsw-alias-brand-primary-invert': { light: '#ffffff', dark: '#06131c' },
    '--dsw-alias-brand-text': { light: '#0e7f9e', dark: '#56e6ff' },
    '--dsw-alias-link': { light: '#0e7f9e', dark: '#56e6ff' },
    '--dsw-alias-interactive-bg-hover': { light: 'rgba(14, 156, 192, 0.14)', dark: 'rgba(56, 225, 255, 0.22)' },
    '--dsw-alias-interactive-bg-active': { light: 'rgba(124, 92, 255, 0.20)', dark: 'rgba(124, 92, 255, 0.30)' },
    '--dsw-alias-interactive-bg-hover-solid': { light: '#6b4ae6', dark: '#7c5cff' },
  }
}

/**
 * Publish the glass layer through the theme service.
 * @param ctx - Client root context.
 */
export function applyGlassTheme(ctx: ClientContext): void {
  const glass = hasCompositing() && !prefersFlat()
  ctx.effect(() => ctx.theme.overrideTokens(SOURCE, buildGlassTokens(glass)), 'ui-brand-qizhi: glass token layer')
}
