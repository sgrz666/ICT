import { useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import css from './brand.module.css'

/** Particle budget per viewport area, so a 4K screen does not get 4K nodes. */
const PIXELS_PER_PARTICLE = 26_000
const MIN_PARTICLES = 24
const MAX_PARTICLES = 90
/** Link two nodes when closer than this many pixels. */
const LINK_DISTANCE = 132
/** Drift speed in pixels per second; deliberately slow for an ambient layer. */
const SPEED = 11
/** Node colors, stored by index in `Nodes.tints`. */
const TINTS = ['56, 226, 255', '124, 92, 255', '78, 240, 176'] as const
const FALLBACK_TINT = '56, 226, 255'

/** One parallel array per node attribute; all share `count` entries. */
interface Nodes {
  /** Nodes held. */
  count: number
  /** Viewport width the positions were laid out against. */
  width: number
  /** Viewport height the positions were laid out against. */
  height: number
  xs: Float32Array
  ys: Float32Array
  vx: Float32Array
  vy: Float32Array
  tints: Uint8Array
}

/** The state before the first layout: no nodes, no viewport to scale from. */
const EMPTY_NODES: Nodes = {
  count: 0,
  width: 0,
  height: 0,
  xs: new Float32Array(0),
  ys: new Float32Array(0),
  vx: new Float32Array(0),
  vy: new Float32Array(0),
  tints: new Uint8Array(0),
}

/**
 * Read a node array slot with the absent value expressed as zero, so
 * `noUncheckedIndexedAccess` stays satisfied at every call site.
 * @param values - the attribute array.
 * @param index - node index.
 * @returns the stored value, or 0 when the index is out of range.
 */
function at(values: Float32Array | Uint8Array, index: number): number {
  return values[index] ?? 0
}

/**
 * Allocate a node set, carrying existing positions and velocities forward
 * proportionally when the viewport size changes.
 * @param count - nodes to hold.
 * @param previous - the outgoing set.
 * @param width - current viewport width in CSS pixels.
 * @param height - current viewport height in CSS pixels.
 * @returns the node set to draw.
 */
function seedNodes(count: number, previous: Nodes, width: number, height: number): Nodes {
  const nodes: Nodes = {
    count,
    width,
    height,
    xs: new Float32Array(count),
    ys: new Float32Array(count),
    vx: new Float32Array(count),
    vy: new Float32Array(count),
    tints: new Uint8Array(count),
  }
  const reuse = previous.count > 0 && previous.width > 0 && previous.height > 0
  for (let i = 0; i < count; i += 1) {
    const carried = reuse && i < previous.count
    nodes.xs[i] = carried ? at(previous.xs, i) * (width / previous.width) : Math.random() * width
    nodes.ys[i] = carried ? at(previous.ys, i) * (height / previous.height) : Math.random() * height
    const angle = Math.random() * Math.PI * 2
    nodes.vx[i] = carried ? at(previous.vx, i) : Math.cos(angle) * SPEED
    nodes.vy[i] = carried ? at(previous.vy, i) : Math.sin(angle) * SPEED
    nodes.tints[i] = carried ? at(previous.tints, i) : Math.floor(Math.random() * TINTS.length)
  }
  return nodes
}

/**
 * Ambient node-network layer behind the empty-session hero.
 *
 * A single Canvas 2D pass: no animation library, no WebGL, no worker. Each
 * frame moves every node, wraps it at the viewport edge, and strokes the links
 * that fall inside {@link LINK_DISTANCE}. It stops while the document is
 * hidden, renders one static frame under `prefers-reduced-motion`, and removes
 * its resize and visibility listeners on unmount, so leaving the hero ends all
 * work. The element is `pointer-events: none`, so it cannot intercept the
 * composer, the workspace chip, or any menu.
 * @returns the particle canvas element.
 */
export function ParticleField() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const host = canvas.current
    if (host === null) return
    const graphics = host.getContext('2d')
    if (graphics === null) return
    // The guards above narrow both values; these bindings carry the non-null
    // types into the helpers below, which are reachable from the listeners.
    const surface: CanvasRenderingContext2D = graphics

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)')
    let viewport = { width: 0, height: 0 }
    let nodes = EMPTY_NODES
    let frame = 0

    /**
     * Paint one frame: links first, then nodes on top.
     * @param set - the nodes to render.
     */
    const draw = (set: Nodes): void => {
      surface.clearRect(0, 0, viewport.width, viewport.height)
      for (let i = 0; i < set.count; i += 1) {
        for (let j = i + 1; j < set.count; j += 1) {
          const dx = at(set.xs, i) - at(set.xs, j)
          const dy = at(set.ys, i) - at(set.ys, j)
          const distance = Math.hypot(dx, dy)
          if (distance > LINK_DISTANCE) continue
          const alpha = 0.16 * (1 - distance / LINK_DISTANCE)
          surface.strokeStyle = `rgba(${TINTS[at(set.tints, i)] ?? FALLBACK_TINT}, ${alpha})`
          surface.lineWidth = 0.6
          surface.beginPath()
          surface.moveTo(at(set.xs, i), at(set.ys, i))
          surface.lineTo(at(set.xs, j), at(set.ys, j))
          surface.stroke()
        }
      }
      for (let i = 0; i < set.count; i += 1) {
        surface.fillStyle = `rgba(${TINTS[at(set.tints, i)] ?? FALLBACK_TINT}, 0.5)`
        surface.beginPath()
        surface.arc(at(set.xs, i), at(set.ys, i), i % 7 === 0 ? 1.7 : 1.1, 0, Math.PI * 2)
        surface.fill()
      }
    }

    /**
     * Advance every node by one frame interval and wrap it at the edges.
     * @param set - the nodes to move.
     * @param seconds - elapsed frame time, already clamped.
     */
    const step = (set: Nodes, seconds: number): void => {
      for (let i = 0; i < set.count; i += 1) {
        let x = at(set.xs, i) + at(set.vx, i) * seconds
        let y = at(set.ys, i) + at(set.vy, i) * seconds
        if (x < -8) x = viewport.width + 8
        else if (x > viewport.width + 8) x = -8
        if (y < -8) y = viewport.height + 8
        else if (y > viewport.height + 8) y = -8
        set.xs[i] = x
        set.ys[i] = y
      }
    }

    /** Resize to the viewport and reseed nodes proportionally to its area. */
    const layout = (): void => {
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      viewport = { width: window.innerWidth, height: window.innerHeight }
      host.width = Math.floor(viewport.width * ratio)
      host.height = Math.floor(viewport.height * ratio)
      surface.setTransform(ratio, 0, 0, ratio, 0, 0)
      const count = Math.max(
        MIN_PARTICLES,
        Math.min(MAX_PARTICLES, Math.round((viewport.width * viewport.height) / PIXELS_PER_PARTICLE)),
      )
      nodes = seedNodes(count, nodes, viewport.width, viewport.height)
      draw(nodes)
    }

    let previous = performance.now()
    /** Animation driver; suppressed entirely under reduced motion. */
    const loop = (now: number): void => {
      step(nodes, Math.min(now - previous, 64) / 1000)
      previous = now
      draw(nodes)
      frame = requestAnimationFrame(loop)
    }

    /** Start or stop the loop for the current visibility and preference. */
    const sync = (): void => {
      if (frame !== 0) {
        cancelAnimationFrame(frame)
        frame = 0
      }
      if (reduced.matches || document.hidden) {
        draw(nodes)
        return
      }
      previous = performance.now()
      frame = requestAnimationFrame(loop)
    }

    layout()
    sync()
    window.addEventListener('resize', layout)
    document.addEventListener('visibilitychange', sync)
    reduced.addEventListener('change', sync)

    return () => {
      if (frame !== 0) cancelAnimationFrame(frame)
      window.removeEventListener('resize', layout)
      document.removeEventListener('visibilitychange', sync)
      reduced.removeEventListener('change', sync)
    }
  }, [])

  return createPortal(<canvas ref={canvas} className={css.particles} aria-hidden="true" />, document.body)
}
